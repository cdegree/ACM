FILES
-----

[A-J].txt       -- input files
[A-J].ans       -- output files
zz-decimal.jar  -- output validators



HOW TO JUDGE
------------

Problem E:
    java -jar zz-decimal.jar -e 1e-6 E.txt E.yours.txt E.ans

Problem F:
    java -jar zz-decimal.jar -e 1e-3 F.txt F.yours.txt F.ans

Problem G:
    java -jar zz-decimal.jar -e 1e-6 G.txt G.yours.txt G.ans

Other problems:
    Use a simple file comparison utility such as "diff" or "fc".



NOTE ON VALIDATOR
-----------------

You can see why your output is rejected by the option "-c":

    java -jar zz-decimal.jar -c -e 1e-6 E.txt E.yours.txt E.ans




STATUS OF FILES
---------------

All files included in this archive were created by the members of
Japanese Alumni Group.



TERMS OF USE
------------

You may use all files in this archive, in any form, entirely or in
part, with or without modification, for any purposes, without prior
or posterior consent to Japanese Alumni Group, provided that your
use is made solely at your own risk.

THIS ARCHIVE IS PROVIDED "AS-IS", WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY.  IN NO EVENT SHALL JAPANESE ALUMNI GROUP, THE MEMBERS
OF THE GROUP, OR THE CONTRIBUTORS TO THE GROUP BE LIABLE FOR ANY
DAMAGE ARISING IN ANY WAY OUT OF THE USE OF THE PROBLEM SET, EVEN
IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

